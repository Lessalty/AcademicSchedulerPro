package queue;

public class QueueInterface {

}
